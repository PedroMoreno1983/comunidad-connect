# CoCo · Cargador de carros (vista previa PR #53)

Extensión Manifest V3 que recibe una canasta de Convive Connect y agrega los
productos en la sesión real del comprador. La versión 0.3.2 conecta el botón de Convive, conserva y declara lo que ya había en el carro, abre el carro al terminar e incluye adaptadores
independientes para Lider, Jumbo, Santa Isabel, Unimarc, Tottus, aCuenta e
Irurzun.

## Alcance de seguridad

- Sólo acepta planes iniciados desde `conviveconnect.com`.
- Sólo navega y actúa en los dominios de supermercados declarados en el manifest.
- Cada URL exacta de producto se valida contra los dominios de su propia tienda.
- No lee contraseñas, medios de pago ni datos del checkout.
- No confirma pedidos, no reserva horarios y no ejecuta pagos.
- Pausa ante CAPTCHA, verificación humana o selección de entrega y permite reanudar.
- Verifica que el carro cambió después de cada clic; un clic sin cambio no se reporta como éxito.
- Detecta el conteo previo del carro y lo separa de los productos agregados por CoCo.
- Persiste el avance para continuar producto por producto y no detiene toda la lista por un faltante.

## Comportamiento por tienda

| Tienda | Flujo |
| --- | --- |
| Lider | Ficha exacta o búsqueda; pausa ante el control humano de Walmart. |
| Jumbo | Ficha o búsqueda Cencosud; carga y ajusta cantidades. |
| Santa Isabel | Ficha o búsqueda Cencosud; carga y ajusta cantidades. |
| Unimarc | Pausa para elegir despacho/retiro cuando el sitio lo exige. |
| Tottus | Pausa ante Cloudflare; reanuda en la ficha exacta después de la validación humana. |
| aCuenta | Pausa para elegir despacho/retiro cuando el sitio lo exige. |
| Irurzun | Prepara el carro mayorista de cotización; no inventa un precio final. |

Los sitios externos pueden cambiar sus controles sin aviso. Por eso los
adaptadores y sus pruebas deben mantenerse por separado y nunca se debe asumir
éxito sólo porque el clic fue ejecutado.

## Instalación de prueba

1. Descomprime `convive-cart-loader.zip`.
2. Abre `chrome://extensions`.
3. Activa **Modo desarrollador**.
4. Selecciona **Cargar extensión sin empaquetar** y elige esta carpeta.
5. Vuelve a Convive Connect y recarga la página de Supermercado.

Para usuarios finales debe publicarse en Chrome Web Store. La publicación exige
la cuenta de desarrollador del titular de Convive Connect y la revisión de
Google; el código no puede saltarse ese proceso.

## Flujo

1. CoCo envía productos exactos, cantidades y URLs al puente de la extensión.
2. La extensión abre una única pestaña del supermercado en la sesión del comprador.
3. Recorre los productos, verifica cada alta, ajusta cantidades y conserva el avance.
4. Los faltantes se registran y la carga continúa con el siguiente producto.
5. Al finalizar, abre el carro oficial mediante el control visible de la tienda.
6. El comprador revisa disponibilidad, reemplazos, despacho y pago.
