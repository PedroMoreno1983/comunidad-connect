// frontend/src/pages/dashboard/DashboardPage.tsx - ACTUALIZAR

import { useState, useMemo, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { pilotMentionsService } from '../../services/pilotMentionsService';
import { brandService } from '../../services/brandService';
import { useFilterStore } from '../../store/useFilterStore';
import DashboardFilters from '../../components/DashboardFilters';
import BrandOverviewCards from '../../components/BrandOverviewCards';
import {
  MessageSquare, Bot, User, ArrowRight
} from 'lucide-react';
import { format, startOfWeek, endOfWeek, subDays } from 'date-fns';
import { es } from 'date-fns/locale';
import ClipPlayerModal from '../../components/ClipPlayerModal';
import KPICards from '../../components/KPICards';
import MentionsChart from '../../components/MentionsChart';
import SentimentChart from '../../components/SentimentChart';
import MediaTypeChart from '../../components/MediaTypeChart';
import TopMentions from '../../components/TopMentions';
import MediaDistribution from '../../components/MediaDistribution';
import '../../styles/dashboard.css';
import '../../components/DashboardFilters.css';

export default function DashboardPage() {
  const [selectedMentionId, setSelectedMentionId] = useState<string | null>(null);
  const [insightGenerating, setInsightGenerating] = useState(false);
  const [insightError, setInsightError] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const { period, selectedBrandId, setSelectedBrand, getDateRange } = useFilterStore();

  // Pasamos brandId al backend → filtra en BD por marca
  // Límite 2000 para cubrir períodos amplios sin truncar
  const { data: allMentions, isLoading, error } = useQuery({
    queryKey: ['pilot-mentions', selectedBrandId],
    queryFn: () => pilotMentionsService.getAll(
      selectedBrandId && selectedBrandId !== 'all' ? selectedBrandId : undefined,
      2000,
    ),
  });

  // Query separada para el Brand Panel — siempre todas las marcas, sin filtro
  const { data: panelMentionsRaw, isFetching: panelFetching, refetch: refetchPanel } = useQuery({
    queryKey: ['pilot-mentions-panel'],
    queryFn: () => pilotMentionsService.getAll(undefined, 500),
    staleTime: 0,
    refetchInterval: 120_000,
  });

  // Marcas para el panel
  const { data: brands } = useQuery({
    queryKey: ['brands-panel'],
    queryFn: () => brandService.getAll(),
    staleTime: 60_000,
  });

  // Filtrar menciones del panel a los últimos 7 días
  const panelMentions = useMemo(() => {
    if (!panelMentionsRaw) return [];
    const from = subDays(new Date(), 7);
    return panelMentionsRaw.filter((m: any) => {
      const date = new Date(m.timestamp || m.detectedAt || 0);
      return date >= from;
    });
  }, [panelMentionsRaw]);

  // Insight IA — polling dinámico: cada 3s mientras genera, cada 5min en reposo
  const { data: insightData, refetch: refetchInsight } = useQuery({
    queryKey: ['pilot-insight'],
    queryFn: () => pilotMentionsService.getInsight(),
    refetchInterval: (query: any) =>
      query.state.data?.generating ? 3_000 : 5 * 60 * 1000,
    staleTime: 0,
  });

  // Sincronizar estado local con el flag del backend:
  // cuando el backend termina (generating → false), limpiar spinner
  // y mostrar error si la generación falló
  useEffect(() => {
    if (!insightData) return;
    if (!insightData.generating && insightGenerating) {
      setInsightGenerating(false);
      if (insightData.lastError) {
        setInsightError(insightData.lastError);
      }
    }
  }, [insightData?.generating]);

  const handleGenerateInsight = async () => {
    setInsightGenerating(true);
    setInsightError(null);
    // Dispara en background — retorna de inmediato (no espera la inferencia)
    await pilotMentionsService.generateInsight();
    // Refetch para obtener generating=true del backend de inmediato
    await refetchInsight();
  };

  // Combinar estado local (feedback inmediato al click) con estado del backend
  const isGenerating = insightGenerating || insightData?.generating;
  
  const getWeekRange = () => {
    const now = new Date();
    const weekStart = startOfWeek(now, { locale: es });
    const weekEnd = endOfWeek(now, { locale: es });
    
    return `${format(weekStart, "d 'de' MMMM", { locale: es })} - ${format(weekEnd, "d 'de' MMMM 'de' yyyy", { locale: es })}`;
  };

  // El backend ya filtra por brandId. Aquí solo aplicamos el filtro de periodo.
  const recentMentions = useMemo(() => {
    if (!allMentions || allMentions.length === 0) return [];

    const { from } = getDateRange();

    return allMentions.filter((m: any) => {
      const date = new Date(m.timestamp || m.detectedAt || 0);
      return date >= from;
    });
  }, [allMentions, period, getDateRange]);

  const totalMentions = recentMentions?.length || 0;

  // Temas más mencionados:
  // 1. Primero agrupa por keyword (puede haber varias keywords distintas)
  // 2. Si todas las menciones tienen la misma keyword, extrae bigramas/trigramas
  //    frecuentes del campo `context` para mostrar temas reales
  const topTopics = useMemo(() => {
    if (!recentMentions || recentMentions.length === 0) return [];

    const keywordCount = new Map<string, number>();

    recentMentions.forEach((m: any) => {
      const keyword = (m.keyword || '').trim().toLowerCase();
      if (keyword) {
        keywordCount.set(keyword, (keywordCount.get(keyword) || 0) + 1);
      }
    });

    // Si hay solo 1 keyword única → extraer frases del context
    if (keywordCount.size <= 1) {
      const phraseCount = new Map<string, number>();

      // Palabras vacías en español a ignorar
      const stopWords = new Set([
        'de','la','el','en','y','a','que','los','las','del','un','una',
        'por','con','para','es','se','al','lo','su','le','más','ha',
        'este','esta','no','pero','como','su','sus','si','fue','han',
        'son','ya','sobre','también','entre','cuando','hasta','donde',
        'sido','estar','ser','tiene','hay','todo','así','bien','muy',
        'me','te','nos','les','mi','tu','yo','él','she','the','and','of',
        'to','in','is','it','that','was','for','on','are','as','with',
      ]);

      recentMentions.forEach((m: any) => {
        const text = (m.context || m.contextBefore || '').toLowerCase();
        if (!text) return;

        // Extraer bigramas significativos
        const words = text
          .replace(/[^a-záéíóúüñ\s]/gi, ' ')
          .split(/\s+/)
          .filter((w: string) => w.length > 3 && !stopWords.has(w));

        for (let i = 0; i < words.length - 1; i++) {
          const bigram = `${words[i]} ${words[i + 1]}`;
          phraseCount.set(bigram, (phraseCount.get(bigram) || 0) + 1);
        }
      });

      // Retornar los bigramas más frecuentes (mínimo 2 apariciones)
      const phrases = Array.from(phraseCount.entries())
        .filter(([, c]) => c >= 2)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6)
        .map(([topic, count]) => ({
          topic: topic.charAt(0).toUpperCase() + topic.slice(1),
          count,
        }));

      if (phrases.length > 0) return phrases;
    }

    // Caso normal: múltiples keywords → agrupar por keyword
    return Array.from(keywordCount.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([topic, count]) => ({
        topic: topic.charAt(0).toUpperCase() + topic.slice(1),
        count,
      }));
  }, [recentMentions]);

  // Vocerías - Por ahora simulado, necesitaría análisis NLP
  const spokespersons = useMemo(() => {
    return [
      { name: 'No Aplica', mentions: totalMentions, proactive: 0 },
    ];
  }, [totalMentions]);


  return (
    <div className="dashboard-container">
      <div className="dashboard-inner">

        {/* ── PANEL DE MARCAS ── siempre visible, datos últimos 7 días */}
        {brands && brands.length > 0 && (
          <BrandOverviewCards
            brands={brands}
            mentions={panelMentions}
            activeBrandId={selectedBrandId}
            onBrandFilter={(brandId) => setSelectedBrand(brandId)}
            onRefresh={() => {
              refetchPanel();
              queryClient.invalidateQueries({ queryKey: ['pilot-mentions', selectedBrandId] });
            }}
            isRefreshing={panelFetching}
          />
        )}

        {/* ── SEPARADOR ── */}
        <div style={{
          borderTop: '1px solid var(--border-color)',
          marginBottom: '24px',
          paddingTop: '24px',
        }}>
          <div className="dashboard-header-row">
            <div className="dashboard-header-info">
              <h1 className="period-title">Análisis Detallado</h1>
              <p className="period-range">
                {getWeekRange()}
              </p>
            </div>
            <DashboardFilters />
          </div>
        </div>

        {/* Loading analytics */}
        {isLoading && (
          <div className="glass-card" style={{ padding: '40px', textAlign: 'center' }}>
            <MessageSquare size={40} style={{ color: 'var(--text-muted)', margin: '0 auto 12px' }} />
            <p style={{ color: 'var(--text-muted)' }}>Cargando análisis...</p>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="glass-card" style={{ padding: '40px', textAlign: 'center' }}>
            <p style={{ color: '#ef4444' }}>Error: {String(error)}</p>
          </div>
        )}

        {/* Sin menciones para el período/marca seleccionada */}
        {!isLoading && !error && allMentions && allMentions.length > 0 && recentMentions.length === 0 && (
          <div className="glass-card" style={{ padding: '40px', textAlign: 'center' }}>
            <MessageSquare size={40} style={{ color: 'var(--text-muted)', margin: '0 auto 12px' }} />
            <h3 style={{ fontSize: '18px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '8px' }}>
              No hay menciones para este período
            </h3>
            <p style={{ fontSize: '14px', color: 'var(--text-muted)' }}>
              Intenta cambiar el período o la marca seleccionada.
            </p>
          </div>
        )}

        {!isLoading && !error && (!allMentions || allMentions.length === 0) && (
          <div className="glass-card" style={{ padding: '40px', textAlign: 'center' }}>
            <MessageSquare size={40} style={{ color: 'var(--text-muted)', margin: '0 auto 12px' }} />
            <h3 style={{ fontSize: '18px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '8px' }}>
              No hay menciones disponibles
            </h3>
            <p style={{ fontSize: '14px', color: 'var(--text-muted)' }}>
              El sistema está monitoreando automáticamente. Las menciones aparecerán aquí cuando sean detectadas.
            </p>
          </div>
        )}

        {recentMentions.length > 0 && (
          <>
            {/* KPI Cards */}
            <KPICards mentions={recentMentions} />

            {/* AI INSIGHT CARD */}
            <div style={{
              position: 'relative',
              overflow: 'hidden',
              background: 'linear-gradient(135deg, rgba(99, 102, 241, 0.15) 0%, rgba(99, 102, 241, 0.05) 100%)',
              border: '1px solid rgba(99, 102, 241, 0.2)',
              borderRadius: '12px',
              padding: '20px 24px',
              marginBottom: '24px',
              display: 'flex',
              alignItems: 'center',
              gap: '20px'
            }}>
              <div style={{
                flexShrink: 0,
                width: '48px',
                height: '48px',
                borderRadius: '12px',
                background: 'rgba(99, 102, 241, 0.2)',
                backdropFilter: 'blur(12px)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#6366f1'
              }}>
                <Bot size={24} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                  <span style={{
                    fontSize: '11px',
                    fontWeight: 700,
                    color: '#6366f1',
                    letterSpacing: '0.05em'
                  }}>INSIGHT IA</span>
                  {/* Pulso: rojo=error, naranja=generando, púrpura=ok, gris=vacío */}
                  <span style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    background: insightError ? '#ef4444'
                      : isGenerating ? '#f59e0b'
                      : insightData?.text ? '#6366f1'
                      : '#4b5563',
                    animation: insightError ? 'none'
                      : isGenerating ? 'pulse 1s ease-in-out infinite'
                      : insightData?.text ? 'pulse 2s ease-in-out infinite'
                      : 'none'
                  }}></span>
                  {insightError && (
                    <span style={{ fontSize: '10px', color: '#ef4444', fontWeight: 600 }}>
                      IA no disponible
                    </span>
                  )}
                  {isGenerating && !insightError && (
                    <span style={{ fontSize: '10px', color: '#f59e0b', fontWeight: 600 }}>
                      Generando...
                    </span>
                  )}
                  {!isGenerating && !insightError && insightData?.generatedAt && (
                    <span style={{ fontSize: '10px', color: 'var(--text-muted)' }}>
                      {format(new Date(insightData.generatedAt), "HH:mm 'del' d MMM", { locale: es })}
                    </span>
                  )}
                </div>
                <p style={{
                  fontSize: '14px',
                  fontWeight: 500,
                  color: insightError ? '#ef4444'
                    : isGenerating ? 'var(--text-muted)'
                    : insightData?.text ? 'var(--text-primary)'
                    : 'var(--text-muted)',
                  margin: 0,
                  lineHeight: 1.5,
                  fontStyle: insightError || (!insightData?.text && !isGenerating) ? 'italic' : 'normal'
                }}>
                  {insightError
                    ?? (isGenerating
                      ? (insightData?.text ?? 'Analizando menciones con IA local, esto puede tardar 1-2 minutos en CPU...')
                      : (insightData?.text ?? 'El insight se generará automáticamente con IA local en los próximos minutos.')
                    )}
                </p>
              </div>
              <button
                onClick={handleGenerateInsight}
                disabled={isGenerating}
                title="Generar insight ahora"
                style={{
                  flexShrink: 0,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  padding: '10px 20px',
                  background: 'transparent',
                  border: '1px solid rgba(99, 102, 241, 0.3)',
                  borderRadius: '8px',
                  color: isGenerating ? 'var(--text-muted)' : 'var(--text-primary)',
                  fontSize: '13px',
                  fontWeight: 500,
                  cursor: isGenerating ? 'wait' : 'pointer',
                  opacity: isGenerating ? 0.7 : 1,
                  transition: 'opacity 0.2s'
                }}>
                {isGenerating ? 'Generando...' : 'Actualizar'}
                {!isGenerating && <ArrowRight size={16} />}
              </button>
            </div>

            {/* MENCIONES Y ALCANCE + SENTIMIENTO - MISMA FILA */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: '2fr 1fr',
              gap: '24px',
              marginBottom: '24px'
            }}>
              <MentionsChart mentions={recentMentions} period={period} />
              <SentimentChart mentions={recentMentions} />
            </div>

            {/* TIPO DE MEDIO + TOP MENTIONS + MEDIA DISTRIBUTION */}
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '24px',
              marginBottom: '24px'
            }}>
              <MediaTypeChart mentions={recentMentions} />
              <TopMentions 
                mentions={recentMentions} 
                onMentionClick={(id) => setSelectedMentionId(id)}
              />
              <MediaDistribution mentions={recentMentions} />
            </div>

            {/* VOCERIAS + TEMAS + FLUJO */}
            <div className="content-grid-3-col">
              <div className="glass-card widget-card-small">
                <div className="widget-header">
                  <User size={16} />
                  <h3 className="widget-title-small">Vocerías</h3>
                </div>
                <div className="vocerias-container">
                  <div className="vocerias-main">
                    <span className="vocerias-main-label">TOTAL</span>
                    <div className="vocerias-main-value">
                      <span className="vocerias-number">{totalMentions}</span>
                      <span className="vocerias-subtext">(0 proactivas)</span>
                    </div>
                  </div>
                  {spokespersons.map((person, index) => (
                    <div key={index} className="voceria-row">
                      <span className="voceria-name">{person.name}</span>
                      <div className="voceria-stats">
                        <span className="voceria-count">{person.mentions}</span>
                        <span className="voceria-proactive">({person.proactive} proactivas)</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-card widget-card-small">
                <div className="widget-header">
                  <MessageSquare size={16} />
                  <h3 className="widget-title-small">Temas más mencionados</h3>
                </div>
                <div className="topics-container">
                  {topTopics.length > 0 ? (
                    topTopics.map((topic, index) => (
                      <div 
                        key={index} 
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          padding: '12px 16px',
                          borderRadius: '8px',
                          backgroundColor: 'rgba(16, 185, 129, 0.1)',
                          border: '1px solid rgba(16, 185, 129, 0.2)',
                          transition: 'all 0.2s ease',
                          cursor: 'pointer',
                        }}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.15)';
                          e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.3)';
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.backgroundColor = 'rgba(16, 185, 129, 0.1)';
                          e.currentTarget.style.borderColor = 'rgba(16, 185, 129, 0.2)';
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                          <span style={{
                            fontSize: '18px',
                            fontWeight: 700,
                            color: 'var(--text-muted)',
                            minWidth: '28px'
                          }}>
                            #{index + 1}
                          </span>
                          <span style={{
                            fontSize: '14px',
                            fontWeight: 500,
                            color: 'var(--text-primary)'
                          }}>
                            {topic.topic}
                          </span>
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                          <svg 
                            width="14" 
                            height="14" 
                            viewBox="0 0 24 24" 
                            fill="none" 
                            stroke="#10b981" 
                            strokeWidth="2"
                          >
                            <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
                            <polyline points="17 6 23 6 23 12" />
                          </svg>
                          <span style={{
                            fontSize: '13px',
                            fontFamily: 'monospace',
                            color: 'var(--text-muted)'
                          }}>
                            ({topic.count})
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div style={{ 
                      padding: '20px', 
                      textAlign: 'center', 
                      color: 'var(--text-muted)',
                      fontSize: '13px'
                    }}>
                      Sin datos disponibles
                    </div>
                  )}
                </div>
              </div>

              <div className="glass-card widget-card-small">
                <div className="widget-header">
                  <ArrowRight size={16} />
                  <h3 className="widget-title-small">Flujo Vocero - Medio</h3>
                </div>
                <div className="flow-container">
                  <div style={{
                    padding: '20px',
                    textAlign: 'center',
                    color: 'var(--text-muted)',
                    fontSize: '13px'
                  }}>
                    Pendiente de implementación
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>

      {selectedMentionId && (
        <ClipPlayerModal 
          mentionId={selectedMentionId} 
          onClose={() => setSelectedMentionId(null)} 
        />
      )}
    </div>
  );
}