// frontend/src/layouts/DashboardLayout.tsx

import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Tag,
  Globe,
  MessageSquare,
  LogOut,
  Menu,
  X,
  Search,
  Settings,
  User,
  Moon,
  Sun,
  Heart,
  Radio,
  Bell,
  FileText,
  Sparkles
} from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useThemeStore } from '../store/themeStore';
import { useState, useEffect, useRef } from 'react';
import logoImg from '../img/lettersw.png';
import iconImg from '../img/icon.png';
import NotificationPanel from '../components/NotificationPanel';
import AICopilotWidget from '../components/AICopilotWidget';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { name: 'Marcas', href: '/dashboard/brands', icon: Tag },
  { name: 'Fuentes', href: '/dashboard/sources', icon: Globe },
  { name: 'Menciones', href: '/dashboard/mentions', icon: MessageSquare },
  { name: 'Monitor en vivo', href: '/dashboard/live-transcripts', icon: Radio },
  { name: 'Alertas', href: '/dashboard/alerts', icon: Bell },
  { name: 'Reportes', href: '/dashboard/reports', icon: FileText },
  { name: 'Análisis IA', href: '/dashboard/ai-analysis', icon: Sparkles },
];

export default function DashboardLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { isDark, toggleTheme } = useThemeStore();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(true);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 });

  // ── Buscador global ──────────────────────────────────────────────────────────
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const searchInputRef = useRef<HTMLInputElement>(null);

  const openSearch = () => setSearchOpen(true);
  const closeSearch = () => { setSearchOpen(false); setSearchQuery(''); };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.trim();
    if (q) {
      navigate(`/dashboard/mentions?search=${encodeURIComponent(q)}`);
      closeSearch();
    }
  };

  useEffect(() => {
    if (searchOpen) {
      // pequeño delay para que el elemento sea visible antes del focus
      setTimeout(() => searchInputRef.current?.focus(), 50);
    }
  }, [searchOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && searchOpen) closeSearch();
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [searchOpen]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const currentPage = navigation.find(item => item.href === location.pathname);

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleClickOutside = () => setUserMenuOpen(false);
    if (userMenuOpen) {
      document.addEventListener('click', handleClickOutside);
      return () => document.removeEventListener('click', handleClickOutside);
    }
  }, [userMenuOpen]);

  const handleMouseEnter = (itemName: string, event: React.MouseEvent) => {
    if (sidebarCollapsed) {
      const rect = event.currentTarget.getBoundingClientRect();
      setTooltipPosition({
        top: rect.top + rect.height / 2,
        left: rect.right + 8
      });
      setHoveredItem(itemName);
    }
  };

  const handleMouseLeave = () => {
    setHoveredItem(null);
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--bg-body)' }}>
    
      {/* Sidebar Desktop - Collapsible */}
      <aside 
        className="hidden lg:fixed lg:inset-y-0 lg:flex lg:flex-col z-40 transition-all duration-300"
        style={{ width: sidebarCollapsed ? '80px' : '256px' }}
      >
        <div className="flex flex-col flex-grow" style={{ backgroundColor: 'var(--bg-sidebar)', borderRight: '1px solid var(--border-color)' }}>
          {/* Logo */}
          <div className="flex items-center justify-center h-16 flex-shrink-0 px-4" style={{ borderBottom: '1px solid var(--border-color)' }}>
            {sidebarCollapsed ? (
              <img src={iconImg} alt="Scrapp" className="h-10 w-10" />
            ) : (
              <img src={logoImg} alt="Scrapp Monitor" className="h-8 w-auto" />
            )}
          </div>

          {/* Navigation */}
          <nav className="flex-1 px-3 py-6 space-y-1 overflow-y-auto">
            {navigation.map((item) => {
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  className="group flex items-center px-3 py-3 text-sm font-semibold rounded-lg transition-all relative"
                  style={{
                    backgroundColor: isActive ? 'var(--primary)' : 'transparent',
                    color: isActive ? '#ffffff' : 'var(--text-secondary)',
                    justifyContent: sidebarCollapsed ? 'center' : 'flex-start',
                  }}
                  onMouseEnter={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.backgroundColor = 'var(--bg-body)';
                      e.currentTarget.style.color = 'var(--text-primary)';
                    }
                    handleMouseEnter(item.name, e);
                  }}
                  onMouseLeave={(e) => {
                    if (!isActive) {
                      e.currentTarget.style.backgroundColor = 'transparent';
                      e.currentTarget.style.color = 'var(--text-secondary)';
                    }
                    handleMouseLeave();
                  }}
                >
                  <item.icon className={`h-5 w-5 ${sidebarCollapsed ? '' : 'mr-3'}`} />
                  {!sidebarCollapsed && <span>{item.name}</span>}
                </Link>
              );
            })}
          </nav>

          {/* User Section Desktop */}
          {!sidebarCollapsed ? (
            <div className="flex-shrink-0 p-4" style={{ borderTop: '1px solid var(--border-color)' }}>
              <div className="flex items-center">
                <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%)' }}>
                  <User className="h-5 w-5 text-white" />
                </div>
                <div className="ml-3 flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: 'var(--text-primary)' }}>
                    {user?.firstName || user?.email}
                  </p>
                  <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>{user?.email}</p>
                </div>
                <button
                  onClick={handleLogout}
                  className="ml-3 p-2 rounded-lg transition-colors hover:bg-red-50 dark:hover:bg-red-900/20"
                  style={{ color: 'var(--text-muted)' }}
                  title="Cerrar sesión"
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            </div>
          ) : (
            <div className="flex-shrink-0 p-3 flex justify-center" style={{ borderTop: '1px solid var(--border-color)' }}>
              <button
                onClick={handleLogout}
                className="p-2 rounded-lg transition-colors hover:bg-red-50 dark:hover:bg-red-900/20"
                style={{ color: 'var(--text-muted)' }}
                title="Cerrar sesión"
              >
                <LogOut className="h-5 w-5" />
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* Tooltip flotante con position fixed */}
      {hoveredItem && sidebarCollapsed && (
        <div 
          className="fixed px-3 py-2 rounded-lg shadow-lg whitespace-nowrap z-50 pointer-events-none transition-opacity duration-200"
          style={{ 
            backgroundColor: 'var(--bg-card)', 
            border: '1px solid var(--border-color)', 
            color: 'var(--text-primary)',
            top: `${tooltipPosition.top}px`,
            left: `${tooltipPosition.left}px`,
            transform: 'translateY(-50%)'
          }}
        >
          {hoveredItem}
        </div>
      )}

      {/* Mobile Sidebar */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div 
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
            onClick={() => setSidebarOpen(false)}
          />
          
          <div 
            className="fixed inset-y-0 left-0 w-64 flex flex-col"
            style={{ backgroundColor: 'var(--bg-sidebar)' }}
          >
            <div className="flex items-center justify-between h-16 px-6" style={{ borderBottom: '1px solid var(--border-color)' }}>
              <img src={logoImg} alt="Scrapp Monitor" className="h-8 w-auto" />
              <button
                onClick={() => setSidebarOpen(false)}
                className="p-2 rounded-lg transition-colors hover:bg-gray-100 dark:hover:bg-gray-800"
                style={{ color: 'var(--text-muted)' }}
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
              {navigation.map((item) => {
                const isActive = location.pathname === item.href;
                return (
                  <Link
                    key={item.name}
                    to={item.href}
                    onClick={() => setSidebarOpen(false)}
                    className="group flex items-center px-4 py-3 text-sm font-semibold rounded-lg transition-all"
                    style={{
                      backgroundColor: isActive ? 'var(--primary)' : 'transparent',
                      color: isActive ? '#ffffff' : 'var(--text-secondary)',
                    }}
                  >
                    <item.icon className="mr-3 h-5 w-5" />
                    {item.name}
                  </Link>
                );
              })}
            </nav>

            <div className="flex-shrink-0 p-4" style={{ borderTop: '1px solid var(--border-color)' }}>
              <div className="flex items-center mb-3">
                <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%)' }}>
                  <User className="h-5 w-5 text-white" />
                </div>
                <div className="ml-3 flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate" style={{ color: 'var(--text-primary)' }}>
                    {user?.firstName || user?.email}
                  </p>
                  <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>{user?.email}</p>
                </div>
              </div>
              <button
                onClick={() => {
                  handleLogout();
                  setSidebarOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 rounded-lg transition-colors text-white"
                style={{ backgroundColor: 'var(--danger)' }}
              >
                <LogOut className="h-4 w-4" />
                Cerrar Sesión
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div 
        className="flex flex-col flex-1 min-h-screen transition-all duration-300 lg:ml-0"
        style={{ marginLeft: typeof window !== 'undefined' && window.innerWidth >= 1024 ? (sidebarCollapsed ? '80px' : '256px') : '0' }}
      >
        {/* Mobile Header */}
        <header className="sticky top-0 z-30 flex h-16 flex-shrink-0 shadow-sm lg:hidden" style={{ backgroundColor: 'var(--bg-header)', borderBottom: '1px solid var(--border-color)' }}>
          <button 
            onClick={() => setSidebarOpen(true)} 
            className="px-4 flex items-center justify-center border-r"
            style={{ color: 'var(--text-secondary)', borderColor: 'var(--border-color)' }}
            aria-label="Abrir menú"
          >
            <Menu className="h-6 w-6" />
          </button>

          <div className="flex-1 px-4 flex items-center justify-between">
            <h1 className="text-lg font-bold truncate" style={{ color: 'var(--text-primary)' }}>
              {currentPage?.name || 'Dashboard'}
            </h1>

            <div className="flex items-center gap-2">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg transition-colors"
                style={{ color: 'var(--text-muted)' }}
              >
                {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </button>
              <NotificationPanel />
            </div>
          </div>
        </header>

        {/* Desktop Top Bar */}
        <div className="hidden lg:flex items-center justify-between h-16 px-6 sticky top-0 z-30" style={{ backgroundColor: 'var(--bg-header)', borderBottom: '1px solid var(--border-color)' }}>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="p-2 rounded-lg transition-colors hover:bg-gray-100 dark:hover:bg-gray-800"
              style={{ color: 'var(--text-muted)' }}
              title={sidebarCollapsed ? 'Expandir menú' : 'Contraer menú'}
            >
              <Menu className="h-5 w-5" />
            </button>
            <h1 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>
              {currentPage?.name || 'Dashboard'}
            </h1>
          </div>

          <div className="flex items-center gap-2">
            {/* ── Buscador expandible ── */}
            {searchOpen ? (
              <form
                onSubmit={handleSearchSubmit}
                style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
              >
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Buscar menciones..."
                  style={{
                    padding: '6px 12px',
                    borderRadius: '8px',
                    border: '1px solid var(--primary)',
                    background: 'var(--bg-body)',
                    color: 'var(--text-primary)',
                    fontSize: '14px',
                    width: '220px',
                    outline: 'none',
                  }}
                />
                <button
                  type="submit"
                  title="Buscar"
                  style={{
                    padding: '7px 12px',
                    borderRadius: '8px',
                    background: 'var(--primary)',
                    color: 'white',
                    border: 'none',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                >
                  <Search className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={closeSearch}
                  title="Cerrar"
                  style={{
                    padding: '7px',
                    borderRadius: '8px',
                    background: 'transparent',
                    border: '1px solid var(--border-color)',
                    color: 'var(--text-muted)',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                  }}
                >
                  <X className="h-4 w-4" />
                </button>
              </form>
            ) : (
              <button
                onClick={openSearch}
                className="p-2 rounded-lg transition-colors hover:bg-gray-100 dark:hover:bg-gray-800"
                style={{ color: 'var(--text-muted)' }}
                title="Buscar menciones (Clic para abrir)"
              >
                <Search className="h-5 w-5" />
              </button>
            )}

            <button
              onClick={toggleTheme}
              className="p-2 rounded-lg transition-colors hover:bg-gray-100 dark:hover:bg-gray-800"
              style={{ color: 'var(--text-muted)' }}
            >
              {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>

            <NotificationPanel />

            <Link to="/dashboard/account" className="p-2 rounded-lg transition-colors hover:bg-gray-100 dark:hover:bg-gray-800" style={{ color: 'var(--text-muted)' }}>
              <Settings className="h-5 w-5" />
            </Link>

            <div className="relative ml-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setUserMenuOpen(!userMenuOpen);
                }}
                className="w-10 h-10 rounded-full flex items-center justify-center transition-transform hover:scale-105"
                style={{ background: 'linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%)' }}
              >
                <User className="h-5 w-5 text-white" />
              </button>

              {userMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 rounded-lg shadow-lg" style={{ backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)' }}>
                  <div className="py-1">
                    <Link
                      to="/dashboard/account"
                      className="block px-4 py-2 text-sm transition-colors hover:bg-gray-100 dark:hover:bg-gray-800"
                      style={{ color: 'var(--text-primary)' }}
                      onClick={() => setUserMenuOpen(false)}
                    >
                      Mi Cuenta
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="block w-full text-left px-4 py-2 text-sm transition-colors hover:bg-gray-100 dark:hover:bg-gray-800"
                      style={{ color: 'var(--danger)' }}
                    >
                      Cerrar Sesión
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Page Content */}
        <main className="flex-1 py-3 sm:py-4 px-3 sm:px-4">
          <Outlet />
        </main>

        {/* Copiloto IA flotante — disponible en todas las páginas */}
        <AICopilotWidget />

        {/* Footer */}
        <footer className="py-3 sm:py-4 px-4 sm:px-6" style={{ backgroundColor: 'var(--bg-header)', borderTop: '1px solid var(--border-color)' }}>
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs sm:text-sm">
            <div className="flex items-center gap-1" style={{ color: 'var(--text-secondary)' }}>
              Realizado con 
              <Heart className="h-4 w-4 text-red-500 fill-current mx-1" />
              por <span className="font-semibold ml-1" style={{ color: 'var(--primary)' }}>Bigcode</span>
            </div>
            <div style={{ color: 'var(--text-muted)' }}>
              © {new Date().getFullYear()} Scrapp Monitor
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}