// src/components/SentimentChart.tsx
import { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { Smile, Meh, Frown } from 'lucide-react';

interface SentimentChartProps {
  mentions: any[];
}

export default function SentimentChart({ mentions }: SentimentChartProps) {
  console.log('📊 SentimentChart received:', mentions?.length || 0, 'mentions');
  
  const sentimentData = useMemo(() => {
    if (!mentions || mentions.length === 0) {
      console.log('⚠️ SentimentChart: No mentions');
      return {
        data: [
          { name: 'Positiva', value: 0, color: '#10b981' },
          { name: 'Neutra', value: 0, color: '#6b7280' },
          { name: 'Negativa', value: 0, color: '#ef4444' },
        ],
        percentages: { positive: 0, neutral: 0, negative: 0 }
      };
    }
    
    const positive = mentions.filter(m => m.sentiment === 'POSITIVE').length;
    const neutral = mentions.filter(m => m.sentiment === 'NEUTRAL' || !m.sentiment).length;
    const negative = mentions.filter(m => m.sentiment === 'NEGATIVE').length;
    const total = mentions.length;
    
    console.log('📊 SentimentChart stats:', { total, positive, neutral, negative });
    
    return {
      data: [
        { name: 'Positiva', value: positive, color: '#10b981' },
        { name: 'Neutra', value: neutral, color: '#6b7280' },
        { name: 'Negativa', value: negative, color: '#ef4444' },
      ],
      percentages: {
        positive: Math.round((positive / total) * 100),
        neutral: Math.round((neutral / total) * 100),
        negative: Math.round((negative / total) * 100),
      }
    };
  }, [mentions]);

  const sentimentIcons = [
    { 
      label: 'Positiva', 
      icon: Smile, 
      color: '#10b981', 
      value: `${sentimentData.percentages.positive}%` 
    },
    { 
      label: 'Neutra', 
      icon: Meh, 
      color: '#6b7280', 
      value: `${sentimentData.percentages.neutral}%` 
    },
    { 
      label: 'Negativa', 
      icon: Frown, 
      color: '#ef4444', 
      value: `${sentimentData.percentages.negative}%` 
    },
  ];

  return (
    <div className="glass-card" style={{ padding: '24px', height: '100%' }}>
      <div style={{ marginBottom: '16px' }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: 600,
          color: 'var(--text-primary)',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <span style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            backgroundColor: '#f97316'
          }} />
          Noticias segun tono
        </h3>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ position: 'relative', width: '192px', height: '192px' }}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={sentimentData.data}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={75}
                paddingAngle={2}
                dataKey="value"
                strokeWidth={0}
              >
                {sentimentData.data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  borderRadius: '8px',
                  color: 'var(--text-primary)',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          
          <div style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <div style={{ textAlign: 'center' }}>
              <p style={{
                fontSize: '30px',
                fontWeight: 700,
                color: 'var(--text-primary)'
              }}>
                {sentimentData.percentages.positive}%
              </p>
              <p style={{
                fontSize: '12px',
                color: 'var(--text-muted)'
              }}>
                Positivo
              </p>
            </div>
          </div>
        </div>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',
        gap: '8px',
        marginTop: '24px'
      }}>
        {sentimentIcons.map((item) => (
          <div
            key={item.label}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '4px',
              padding: '8px',
              borderRadius: '8px',
              backgroundColor: 'var(--bg-secondary)'
            }}
          >
            <item.icon size={20} style={{ color: item.color }} />
            <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>
              {item.label}
            </span>
            <span style={{ fontSize: '14px', fontWeight: 700, color: item.color }}>
              {item.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}