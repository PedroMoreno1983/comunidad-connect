// src/components/MentionsChart.tsx
import { useMemo } from 'react';
import { Area, AreaChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { format, subDays, startOfDay } from 'date-fns';
import { es } from 'date-fns/locale';

interface MentionsChartProps {
  mentions: any[];
  period: string;
}

export default function MentionsChart({ mentions, period }: MentionsChartProps) {
  console.log('📈 MentionsChart received:', mentions?.length || 0, 'mentions');

  const chartData = useMemo(() => {
    const daysCount = period === 'today' ? 1 : period === '7days' ? 7 : period === '1month' ? 30 : 90;
    const currentDate = new Date();
    
    const groupedByDay = new Map<string, number>();
    
    for (let i = daysCount - 1; i >= 0; i--) {
      const date = startOfDay(subDays(currentDate, i));
      const key = format(date, 'dd MMM', { locale: es });
      groupedByDay.set(key, 0);
    }
    
    mentions.forEach(m => {
      const timestamp = m.timestamp || m.detectedAt || m.publishedAt || m.createdAt;
      if (!timestamp) return;
      
      const date = startOfDay(new Date(timestamp));
      const key = format(date, 'dd MMM', { locale: es });
      
      if (groupedByDay.has(key)) {
        groupedByDay.set(key, (groupedByDay.get(key) || 0) + 1);
      }
    });
    
    return Array.from(groupedByDay.entries()).map(([date, count]) => ({
      date,
      menciones: count,
      alcance: count * 100,
    }));
  }, [mentions, period]);

  const stats = useMemo(() => {
    const total = mentions.length;
    const positive = mentions.filter(m => m.sentiment === 'POSITIVE').length;
    const neutral = mentions.filter(m => m.sentiment === 'NEUTRAL' || !m.sentiment).length;
    const negative = mentions.filter(m => m.sentiment === 'NEGATIVE').length;
    
    return { total, positive, neutral, negative };
  }, [mentions]);

  return (
    <div className="glass-card" style={{ padding: '24px' }}>
      <div style={{ marginBottom: '16px' }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: 600,
          color: 'var(--text-primary)',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <span style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            backgroundColor: '#10b981'
          }} />
          Menciones y Alcance
        </h3>
      </div>

      <div style={{ height: '280px' }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData}>
            <defs>
              <linearGradient id="colorMenciones" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="colorAlcance" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
            <XAxis 
              dataKey="date" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: 'var(--text-muted)', fontSize: 12 }} 
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'var(--text-muted)', fontSize: 12 }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'var(--bg-card)',
                border: '1px solid var(--border-color)',
                borderRadius: '8px',
                color: 'var(--text-primary)',
              }}
            />
            <Legend />
            <Area
              type="monotone"
              dataKey="alcance"
              stroke="#6366f1"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorAlcance)"
              name="Alcance"
            />
            <Area
              type="monotone"
              dataKey="menciones"
              stroke="#10b981"
              strokeWidth={2}
              fillOpacity={1}
              fill="url(#colorMenciones)"
              name="Menciones"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: '16px',
        paddingTop: '20px',
        borderTop: '1px solid var(--border-color)',
        marginTop: '20px'
      }}>
        <div style={{ textAlign: 'center' }}>
          <span style={{ display: 'block', fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px' }}>Total</span>
          <span style={{ display: 'block', fontSize: '20px', fontWeight: 700, color: 'var(--text-primary)' }}>{stats.total}</span>
        </div>
        <div style={{ textAlign: 'center' }}>
          <span style={{ display: 'block', fontSize: '11px', color: '#10b981', marginBottom: '4px' }}>Positivas</span>
          <span style={{ display: 'block', fontSize: '20px', fontWeight: 700, color: '#10b981' }}>{stats.positive}</span>
        </div>
        <div style={{ textAlign: 'center' }}>
          <span style={{ display: 'block', fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px' }}>Neutrales</span>
          <span style={{ display: 'block', fontSize: '20px', fontWeight: 700, color: 'var(--text-primary)' }}>{stats.neutral}</span>
        </div>
        <div style={{ textAlign: 'center' }}>
          <span style={{ display: 'block', fontSize: '11px', color: '#ef4444', marginBottom: '4px' }}>Negativas</span>
          <span style={{ display: 'block', fontSize: '20px', fontWeight: 700, color: '#ef4444' }}>{stats.negative}</span>
        </div>
      </div>
    </div>
  );
}