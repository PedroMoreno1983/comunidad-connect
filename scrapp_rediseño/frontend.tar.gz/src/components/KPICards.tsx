// src/components/KPICards.tsx - COMPLETO
import { useMemo } from 'react';
import { TrendingUp, TrendingDown, Minus, MessageSquare, Users, DollarSign } from 'lucide-react';
import { Area, AreaChart, ResponsiveContainer } from 'recharts';

interface KPICardsProps {
  mentions: any[];
}

type TrendType = 'up' | 'down' | 'neutral';

export default function KPICards({ mentions }: KPICardsProps) {
  console.log('🎯 KPICards - Mentions received:', mentions?.length || 0);

  const stats = useMemo(() => {
    if (!mentions || mentions.length === 0) {
      console.log('⚠️ KPICards - No mentions to process');
      return {
        total: 0,
        monthlyAvg: 0,
        reach: 0,
        value: 0,
        change: 0,
        sparklineData: Array.from({ length: 12 }, () => ({ value: 0 })),
      };
    }

    const total = mentions.length;
    console.log('📊 KPICards - Total mentions:', total);

    const monthlyAvg = Math.round(total / 12);
    const reach = total * 100; // 100 personas por mención
    const value = 0; // Valorización en 0
    const change = monthlyAvg > 0 ? Math.round(((total - monthlyAvg) / monthlyAvg) * 100) : 0;
    
    // Sparkline últimos 12 días
    const sparklineData = Array.from({ length: 12 }, (_, i) => {
      const daysAgo = 11 - i;
      const date = new Date();
      date.setDate(date.getDate() - daysAgo);
      date.setHours(0, 0, 0, 0);
      
      const count = mentions.filter(m => {
        const timestamp = m.timestamp || m.detectedAt || m.publishedAt || m.createdAt;
        if (!timestamp) return false;
        const mDate = new Date(timestamp);
        mDate.setHours(0, 0, 0, 0);
        return mDate.getTime() === date.getTime();
      }).length;
      
      return { value: count };
    });
    
    console.log('📈 KPICards - Sparkline data:', sparklineData);
    
    return {
      total,
      monthlyAvg,
      reach,
      value,
      change,
      sparklineData,
    };
  }, [mentions]);

  const kpis = [
    {
      title: 'Menciones',
      value: stats.total.toLocaleString(),
      change: `${stats.change >= 0 ? '+' : ''}${stats.change}%`,
      trend: stats.change > 0 ? 'up' : stats.change < 0 ? 'down' : 'neutral' as TrendType,
      subtitle: `Promedio mensual ultimos 12 meses: ${stats.monthlyAvg}`,
      icon: MessageSquare,
      color: '#f97316',
      sparkline: stats.sparklineData,
    },
    {
      title: 'Alcance',
      value: stats.reach.toLocaleString(),
      change: `${stats.change >= 0 ? '+' : ''}${stats.change}%`,
      trend: stats.change > 0 ? 'up' : stats.change < 0 ? 'down' : 'neutral' as TrendType,
      subtitle: 'Est. 100 personas por mencion',
      icon: Users,
      color: '#10b981',
      sparkline: null,
    },
    {
      title: 'Valorizacion',
      value: `$${stats.value.toLocaleString()}`,
      change: '+0%',
      trend: 'neutral' as TrendType,
      subtitle: 'Pendiente de calculo',
      icon: DollarSign,
      color: '#6366f1',
      sparkline: null,
    },
  ];

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '24px',
      marginBottom: '24px'
    }}>
      {kpis.map((kpi, index) => (
        <div
          key={kpi.title}
          className="glass-card"
          style={{
            position: 'relative',
            overflow: 'hidden',
            padding: '24px',
            transition: 'border-color 0.2s ease',
          }}
        >
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '16px'
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <div style={{
                padding: '8px',
                borderRadius: '8px',
                backgroundColor: 'var(--bg-secondary)',
              }}>
                <kpi.icon size={16} style={{ color: kpi.color }} />
              </div>
              <span style={{
                fontSize: '14px',
                fontWeight: 500,
                color: 'var(--text-muted)'
              }}>
                {kpi.title}
              </span>
            </div>
            
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '4px',
              fontSize: '12px',
              fontWeight: 500,
              padding: '4px 8px',
              borderRadius: '9999px',
              backgroundColor: kpi.trend === 'up' 
                ? 'rgba(16, 185, 129, 0.1)'
                : kpi.trend === 'down'
                ? 'rgba(239, 68, 68, 0.1)'
                : 'var(--bg-secondary)',
              color: kpi.trend === 'up'
                ? '#10b981'
                : kpi.trend === 'down'
                ? '#ef4444'
                : 'var(--text-muted)'
            }}>
              {kpi.trend === 'up' && <TrendingUp size={12} />}
              {kpi.trend === 'down' && <TrendingDown size={12} />}
              {kpi.trend === 'neutral' && <Minus size={12} />}
              {kpi.change}
            </div>
          </div>

          <p style={{
            fontSize: '36px',
            fontWeight: 700,
            color: 'var(--text-primary)',
            letterSpacing: '-0.02em',
            marginBottom: '8px'
          }}>
            {kpi.value}
          </p>

          {kpi.sparkline && (
            <div style={{ height: '48px', marginBottom: '8px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={kpi.sparkline}>
                  <defs>
                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={kpi.color} stopOpacity={0.3} />
                      <stop offset="100%" stopColor={kpi.color} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Area
                    type="monotone"
                    dataKey="value"
                    stroke={kpi.color}
                    strokeWidth={2}
                    fill={`url(#gradient-${index})`}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}

          {!kpi.sparkline && (
            <div style={{
              height: '48px',
              marginBottom: '8px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: 'rgba(255, 255, 255, 0.02)',
              borderRadius: '6px',
              fontSize: '12px',
              color: 'var(--text-muted)'
            }}>
              Sin datos
            </div>
          )}

          <p style={{
            fontSize: '12px',
            color: 'var(--text-muted)'
          }}>
            {kpi.subtitle}
          </p>
        </div>
      ))}
    </div>
  );
}