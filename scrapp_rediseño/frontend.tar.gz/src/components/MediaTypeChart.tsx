// src/components/MediaTypeChart.tsx
import { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell, Tooltip } from 'recharts';
import { Tv, Radio, Globe, Youtube, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

interface MediaTypeChartProps {
  mentions: any[];
}

// Detecta el tipo de medio/red de una mención
function detectMentionType(m: any): string {
  const sourceType = m.source?.type ?? '';
  const contextBefore = m.contextBefore ?? '';

  // Social media marcados por SocialMediaService con [NETWORK] en contextBefore
  if (contextBefore.startsWith('[YOUTUBE]'))   return 'YouTube';
  if (contextBefore.startsWith('[FACEBOOK]'))  return 'Facebook';
  if (contextBefore.startsWith('[TWITTER]'))   return 'Twitter';
  if (contextBefore.startsWith('[INSTAGRAM]')) return 'Instagram';
  if (contextBefore.startsWith('[LINKEDIN]'))  return 'LinkedIn';

  // Fuentes de tipo SOCIAL_*
  if (sourceType === 'SOCIAL_YOUTUBE')   return 'YouTube';
  if (sourceType === 'SOCIAL_FACEBOOK')  return 'Facebook';
  if (sourceType === 'SOCIAL_TWITTER')   return 'Twitter';
  if (sourceType === 'SOCIAL_INSTAGRAM') return 'Instagram';
  if (sourceType === 'SOCIAL_LINKEDIN')  return 'LinkedIn';

  // Medios tradicionales
  if (sourceType === 'LIVE_STREAM')  return 'TV';
  if (sourceType === 'RADIO_STREAM') return 'Radio';
  return 'Web';
}

const MEDIA_CONFIG: Record<string, { color: string; icon: any }> = {
  TV:        { color: '#ec4899', icon: Tv },
  Radio:     { color: '#8b5cf6', icon: Radio },
  Web:       { color: '#6366f1', icon: Globe },
  YouTube:   { color: '#ff0000', icon: Youtube },
  Facebook:  { color: '#1877f2', icon: Facebook },
  Twitter:   { color: '#1da1f2', icon: Twitter },
  Instagram: { color: '#e1306c', icon: Instagram },
  LinkedIn:  { color: '#0a66c2', icon: Linkedin },
};

export default function MediaTypeChart({ mentions }: MediaTypeChartProps) {
  const mediaData = useMemo(() => {
    const counts: Record<string, number> = {};

    (mentions ?? []).forEach(m => {
      const type = detectMentionType(m);
      counts[type] = (counts[type] ?? 0) + 1;
    });

    return Object.entries(counts)
      .map(([name, value]) => ({
        name,
        value,
        color: MEDIA_CONFIG[name]?.color ?? '#6b7280',
        icon:  MEDIA_CONFIG[name]?.icon  ?? Globe,
      }))
      .sort((a, b) => b.value - a.value);
  }, [mentions]);

  const total = mediaData.reduce((s, d) => s + d.value, 0);

  if (total === 0) {
    return (
      <div className="glass-card" style={{ padding: '24px', height: '100%' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 600, color: 'var(--text-primary)', marginBottom: '12px' }}>
          Menciones por Tipo de Medio
        </h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '13px', textAlign: 'center', padding: '30px 0' }}>
          Sin datos disponibles
        </p>
      </div>
    );
  }

  return (
    <div className="glass-card" style={{ padding: '24px', height: '100%' }}>
      <div style={{ marginBottom: '16px' }}>
        <h3 style={{
          fontSize: '16px', fontWeight: 600, color: 'var(--text-primary)',
          display: 'flex', alignItems: 'center', gap: '8px'
        }}>
          <span style={{
            width: '8px', height: '8px', borderRadius: '50%',
            backgroundColor: '#10b981', display: 'inline-block'
          }} />
          Menciones por Tipo de Medio
        </h3>
      </div>

      <div style={{ height: Math.max(160, mediaData.length * 36) + 'px' }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={mediaData} layout="vertical" margin={{ left: 0, right: 20 }}>
            <XAxis type="number" axisLine={false} tickLine={false}
              tick={{ fill: 'var(--text-muted)', fontSize: 11 }} />
            <YAxis type="category" dataKey="name" axisLine={false} tickLine={false}
              tick={{ fill: 'var(--text-muted)', fontSize: 12 }} width={82} />
            <Tooltip
              contentStyle={{
                backgroundColor: 'var(--bg-card)', border: '1px solid var(--border-color)',
                borderRadius: '8px', color: 'var(--text-primary)',
              }}
              formatter={(value: number) => [`${value} menciones`, '']}
            />
            <Bar dataKey="value" radius={[0, 6, 6, 0]} barSize={22}>
              {mediaData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Leyenda con iconos y porcentajes */}
      <div style={{
        display: 'flex', flexWrap: 'wrap', gap: '8px',
        marginTop: '16px', paddingTop: '16px',
        borderTop: '1px solid var(--border-color)'
      }}>
        {mediaData.map(item => {
          const Icon = item.icon;
          return (
            <div key={item.name} style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <Icon size={13} style={{ color: item.color }} />
              <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{item.name}</span>
              <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--text-primary)' }}>
                {item.value}
              </span>
              <span style={{ fontSize: '11px', color: 'var(--text-muted)', marginRight: '4px' }}>
                ({Math.round((item.value / total) * 100)}%)
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
