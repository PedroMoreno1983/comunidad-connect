// src/components/MediaDistribution.tsx - VERSIÓN CORRECTA

import { useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

interface MediaDistributionProps {
  mentions: any[];
}

export default function MediaDistribution({ mentions }: MediaDistributionProps) {
  console.log('📊 MediaDistribution received:', mentions?.length || 0, 'mentions');

  const chartData = useMemo(() => {
    if (!mentions || mentions.length === 0) {
      return {
        byType: [],
        byChannel: [],
      };
    }

    const typeMap = new Map<string, number>();
    const channelMap = new Map<string, { count: number; type: string }>();

    mentions.forEach(m => {
      const sourceName = m.source?.name || 'Desconocido';
      const sourceType = m.source?.type;

      // BASADO EN BD: LIVE_STREAM = TV, RADIO_STREAM = Radio
      let type = 'Web';
      if (sourceType === 'LIVE_STREAM') {
        type = 'TV';
      } else if (sourceType === 'RADIO_STREAM') {
        type = 'Radio';
      }
      
      typeMap.set(type, (typeMap.get(type) || 0) + 1);

      if (!channelMap.has(sourceName)) {
        channelMap.set(sourceName, { count: 0, type });
      }
      const channel = channelMap.get(sourceName)!;
      channel.count++;
    });

    const byType = [
      { name: 'Web', value: typeMap.get('Web') || 0, color: '#6366f1' },
      { name: 'Radio', value: typeMap.get('Radio') || 0, color: '#8b5cf6' },
      { name: 'TV', value: typeMap.get('TV') || 0, color: '#ec4899' },
    ];

    const channelColors = [
      '#f59e0b', '#ef4444', '#22c55e', '#3b82f6', 
      '#8b5cf6', '#06b6d4', '#ec4899'
    ];

    const byChannel = Array.from(channelMap.entries())
      .map(([name, data], index) => ({
        name,
        value: data.count,
        color: channelColors[index % channelColors.length],
      }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 7);

    console.log('📊 MediaDistribution data:', { byType, byChannel });

    return { byType, byChannel };
  }, [mentions]);

  return (
    <div className="glass-card" style={{ padding: '24px', height: '100%' }}>
      <div style={{ marginBottom: '16px' }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: 600,
          color: 'var(--text-primary)',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <span style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            backgroundColor: '#ec4899'
          }} />
          Menciones por medio
        </h3>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ position: 'relative', width: '208px', height: '208px' }}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData.byChannel}
                cx="50%"
                cy="50%"
                innerRadius={65}
                outerRadius={85}
                paddingAngle={1}
                dataKey="value"
                strokeWidth={0}
              >
                {chartData.byChannel.map((entry, index) => (
                  <Cell key={`outer-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Pie
                data={chartData.byType}
                cx="50%"
                cy="50%"
                innerRadius={40}
                outerRadius={55}
                paddingAngle={2}
                dataKey="value"
                strokeWidth={0}
              >
                {chartData.byType.map((entry, index) => (
                  <Cell key={`inner-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  borderRadius: '8px',
                  color: 'var(--text-primary)',
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          
          <div style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}>
            <div style={{ textAlign: 'center' }}>
              <p style={{
                fontSize: '18px',
                fontWeight: 700,
                color: 'var(--text-primary)'
              }}>
                {mentions.length}
              </p>
              <p style={{
                fontSize: '11px',
                color: 'var(--text-muted)'
              }}>
                Total
              </p>
            </div>
          </div>
        </div>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(2, 1fr)',
        gap: '4px',
        marginTop: '16px',
        fontSize: '11px'
      }}>
        {chartData.byChannel.slice(0, 6).map((item) => (
          <div key={item.name} style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: item.color,
              flexShrink: 0
            }} />
            <span style={{
              color: 'var(--text-muted)',
              overflow: 'hidden',
              textOverflow: 'ellipsis',
              whiteSpace: 'nowrap'
            }}>
              {item.name}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}