// frontend/src/components/BrandOverviewCards.tsx
import { useMemo, type CSSProperties } from 'react';
import { Link } from 'react-router-dom';
import { Tag, Tv, Radio, Globe, ArrowRight, RefreshCw } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';
import { Brand } from '../services/brandService';

interface BrandStats {
  brand: Brand;
  total: number;       // total histórico (backend _count)
  recentCount: number; // menciones en últimos 7 días (para %)
  positive: number;
  neutral: number;
  negative: number;
  tvCount: number;
  radioCount: number;
  webCount: number;
  socialCount: number;
  latestMention: any | null;
}

interface Props {
  brands: Brand[];
  mentions: any[];
  activeBrandId?: string | null;
  onBrandFilter?: (brandId: string | null) => void;
  onRefresh?: () => void;
  isRefreshing?: boolean;
}

export default function BrandOverviewCards({
  brands,
  mentions,
  activeBrandId,
  onBrandFilter,
  onRefresh,
  isRefreshing,
}: Props) {
  const brandStats = useMemo<BrandStats[]>(() => {
    return brands
      .filter((b) => b.isActive)
      .map((brand) => {
        const bm = mentions.filter((m) => m.brand?.id === brand.id);
        const positive = bm.filter((m) => m.sentiment === 'POSITIVE').length;
        const negative = bm.filter((m) => m.sentiment === 'NEGATIVE').length;
        const neutral = bm.length - positive - negative;
        const tvCount = bm.filter((m) => m.source?.type === 'LIVE_STREAM').length;
        const radioCount = bm.filter((m) => m.source?.type === 'RADIO_STREAM').length;
        const webCount = bm.filter((m) =>
          ['WEB_SCRAPE', 'RSS_FEED', 'API'].includes(m.source?.type || ''),
        ).length;
        const socialCount = bm.filter((m) =>
          (m.source?.type || '').startsWith('SOCIAL'),
        ).length;
        const sorted = [...bm].sort((a, b) => {
          const ad = new Date(a.timestamp || a.detectedAt || 0).getTime();
          const bd = new Date(b.timestamp || b.detectedAt || 0).getTime();
          return bd - ad;
        });
        // Total histórico desde el backend (consistente con BrandsPage)
        const historicTotal = brand._count?.mentions ?? bm.length;
        return {
          brand,
          total: historicTotal,
          recentCount: bm.length,   // menciones en los últimos 7 días (para %)
          positive,
          neutral,
          negative,
          tvCount,
          radioCount,
          webCount,
          socialCount,
          latestMention: sorted[0] ?? null,
        };
      })
      .sort((a, b) => b.total - a.total);
  }, [brands, mentions]);

  if (brandStats.length === 0) return null;

  return (
    <div style={{ marginBottom: '28px' }}>
      {/* Section header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
        <div>
          <h2 style={{ fontSize: '18px', fontWeight: 700, color: 'var(--text-primary)', margin: 0 }}>
            Panel de Marcas
          </h2>
          <p style={{ fontSize: '13px', color: 'var(--text-muted)', margin: '4px 0 0' }}>
            Últimos 7 días · {brandStats.length} marcas activas
            {activeBrandId && (
              <span style={{ color: 'var(--primary)', marginLeft: '8px' }}>
                · filtrando análisis
              </span>
            )}
          </p>
        </div>
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
          {activeBrandId && (
            <button
              onClick={() => onBrandFilter?.(null)}
              style={{
                fontSize: '12px', color: 'var(--primary)', background: 'transparent',
                border: '1px solid var(--primary)', borderRadius: '6px',
                padding: '6px 12px', cursor: 'pointer', fontWeight: 600,
              }}
            >
              Ver todas
            </button>
          )}
          <button
            onClick={onRefresh}
            disabled={isRefreshing}
            title="Actualizar panel"
            style={{
              display: 'flex', alignItems: 'center', gap: '6px',
              fontSize: '12px', color: 'var(--text-muted)', background: 'transparent',
              border: '1px solid var(--border-color)', borderRadius: '6px',
              padding: '6px 12px', cursor: 'pointer',
              opacity: isRefreshing ? 0.5 : 1,
            }}
          >
            <RefreshCw
              size={12}
              style={{ animation: isRefreshing ? 'spin 1s linear infinite' : 'none' }}
            />
            Actualizar
          </button>
          <Link
            to="/dashboard/brands"
            style={{
              display: 'flex', alignItems: 'center', gap: '4px',
              fontSize: '13px', color: 'var(--primary)', textDecoration: 'none', fontWeight: 600,
            }}
          >
            Gestionar <ArrowRight size={14} />
          </Link>
        </div>
      </div>

      {/* Cards grid */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
          gap: '16px',
        }}
      >
        {brandStats.map(
          ({ brand, total, recentCount, positive, neutral, negative, tvCount, radioCount, webCount, socialCount, latestMention }) => {
            const isActive = activeBrandId === brand.id;
            // Porcentajes calculados sobre menciones recientes (7 días)
            const base = recentCount > 0 ? recentCount : 1;
            const posP = recentCount > 0 ? Math.round((positive / base) * 100) : 0;
            const negP = recentCount > 0 ? Math.round((negative / base) * 100) : 0;
            const neuP = 100 - posP - negP;

            return (
              <div
                key={brand.id}
                onClick={() => onBrandFilter?.(isActive ? null : brand.id)}
                style={{
                  background: isActive
                    ? 'linear-gradient(135deg, rgba(99,102,241,0.12), rgba(99,102,241,0.04))'
                    : 'rgba(255, 255, 255, 0.04)',
                  border: `1px solid ${isActive ? 'rgba(99,102,241,0.45)' : 'var(--border-color)'}`,
                  borderRadius: '12px',
                  padding: '18px',
                  cursor: 'pointer',
                  transition: 'border-color 0.2s, box-shadow 0.2s',
                }}
                onMouseEnter={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.borderColor = 'rgba(99,102,241,0.3)';
                    e.currentTarget.style.boxShadow = '0 4px 16px rgba(99,102,241,0.1)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (!isActive) {
                    e.currentTarget.style.borderColor = 'var(--border-color)';
                    e.currentTarget.style.boxShadow = 'none';
                  }
                }}
              >
                {/* Brand name + count */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '14px' }}>
                  <div
                    style={{
                      width: '36px', height: '36px', borderRadius: '9px', flexShrink: 0,
                      background: isActive
                        ? 'rgba(99,102,241,0.3)'
                        : 'linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%)',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}
                  >
                    <Tag size={16} color="white" />
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <p
                      style={{
                        fontSize: '14px', fontWeight: 700, color: 'var(--text-primary)',
                        margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                      }}
                    >
                      {brand.name}
                    </p>
                    <p
                      style={{
                        fontSize: '11px', margin: 0, fontWeight: 600,
                        color: total > 0 ? 'var(--primary)' : 'var(--text-muted)',
                      }}
                    >
                      {total > 0 ? `${total} menciones totales` : 'Sin menciones'}
                    </p>
                  </div>
                </div>

                {recentCount > 0 ? (
                  <>
                    {/* Sentiment bar */}
                    <div style={{ marginBottom: '12px' }}>
                      <div
                        style={{
                          display: 'flex', height: '6px', borderRadius: '4px',
                          overflow: 'hidden', gap: '2px',
                        }}
                      >
                        {posP > 0 && (
                          <div
                            style={{ width: `${posP}%`, background: '#10b981', borderRadius: '3px' }}
                            title={`${positive} positivas`}
                          />
                        )}
                        {neuP > 0 && (
                          <div
                            style={{ width: `${neuP}%`, background: '#4b5563', borderRadius: '3px' }}
                            title={`${neutral} neutrales`}
                          />
                        )}
                        {negP > 0 && (
                          <div
                            style={{ width: `${negP}%`, background: '#ef4444', borderRadius: '3px' }}
                            title={`${negative} negativas`}
                          />
                        )}
                      </div>
                      <div style={{ display: 'flex', gap: '10px', marginTop: '6px' }}>
                        <span style={{ fontSize: '11px', color: '#10b981' }}>↑ {positive}</span>
                        <span style={{ fontSize: '11px', color: '#6b7280' }}>● {neutral}</span>
                        <span style={{ fontSize: '11px', color: '#ef4444' }}>↓ {negative}</span>
                      </div>
                    </div>

                    {/* Media type badges */}
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '12px' }}>
                      {tvCount > 0 && (
                        <span
                          style={{
                            display: 'flex', alignItems: 'center', gap: '4px',
                            padding: '3px 8px', borderRadius: '20px',
                            background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)',
                            fontSize: '11px', color: '#ef4444', fontWeight: 600,
                          }}
                        >
                          <Tv size={10} /> {tvCount} TV
                        </span>
                      )}
                      {radioCount > 0 && (
                        <span
                          style={{
                            display: 'flex', alignItems: 'center', gap: '4px',
                            padding: '3px 8px', borderRadius: '20px',
                            background: 'rgba(139,92,246,0.1)', border: '1px solid rgba(139,92,246,0.2)',
                            fontSize: '11px', color: '#8b5cf6', fontWeight: 600,
                          }}
                        >
                          <Radio size={10} /> {radioCount} Radio
                        </span>
                      )}
                      {webCount > 0 && (
                        <span
                          style={{
                            display: 'flex', alignItems: 'center', gap: '4px',
                            padding: '3px 8px', borderRadius: '20px',
                            background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)',
                            fontSize: '11px', color: '#10b981', fontWeight: 600,
                          }}
                        >
                          <Globe size={10} /> {webCount} Web
                        </span>
                      )}
                      {socialCount > 0 && (
                        <span
                          style={{
                            display: 'flex', alignItems: 'center', gap: '4px',
                            padding: '3px 8px', borderRadius: '20px',
                            background: 'rgba(59,130,246,0.1)', border: '1px solid rgba(59,130,246,0.2)',
                            fontSize: '11px', color: '#3b82f6', fontWeight: 600,
                          }}
                        >
                          📱 {socialCount} Social
                        </span>
                      )}
                    </div>

                    {/* Latest mention preview */}
                    {latestMention && (
                      <div
                        style={{
                          padding: '10px', borderRadius: '8px',
                          background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border-color)',
                        }}
                      >
                        <p
                          style={{
                            fontSize: '10px', fontWeight: 600, color: 'var(--text-muted)',
                            marginBottom: '4px', textTransform: 'uppercase', letterSpacing: '0.05em',
                          }}
                        >
                          Última mención
                        </p>
                        <p
                          style={{
                            fontSize: '12px', color: 'var(--text-primary)', margin: '0 0 6px',
                            lineHeight: 1.4,
                            display: '-webkit-box',
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden',
                          } as CSSProperties}
                        >
                          {latestMention.title || latestMention.context || 'Sin título'}
                        </p>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <span style={{ fontSize: '10px', color: 'var(--text-muted)' }}>
                            {latestMention.source?.name || '—'}
                          </span>
                          <span style={{ fontSize: '10px', color: 'var(--text-muted)' }}>
                            {latestMention.timestamp || latestMention.detectedAt
                              ? formatDistanceToNow(
                                  new Date(latestMention.timestamp || latestMention.detectedAt),
                                  { addSuffix: true, locale: es },
                                )
                              : '—'}
                          </span>
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div
                    style={{
                      padding: '14px', borderRadius: '8px', textAlign: 'center',
                      background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border-color)',
                    }}
                  >
                    <p style={{ fontSize: '12px', color: 'var(--text-muted)', margin: 0 }}>
                      Sin menciones en los últimos 7 días
                    </p>
                  </div>
                )}
              </div>
            );
          },
        )}
      </div>
    </div>
  );
}
