// src/components/TopMentions.tsx - VERSIÓN CORRECTA

import { useMemo } from 'react';
import { ExternalLink, Tv, Radio, Globe } from 'lucide-react';

interface TopMentionsProps {
  mentions: any[];
  onMentionClick?: (mentionId: string) => void;
}

const typeIcons = {
  LIVE_STREAM: Tv,
  RADIO_STREAM: Radio,
  WEB_SCRAPE: Globe,
  RSS_FEED: Globe,
  SOCIAL: Globe,
};

const colors = [
  '#ef4444', '#f97316', '#eab308', '#22c55e',
  '#3b82f6', '#8b5cf6', '#ec4899', '#06b6d4'
];

export default function TopMentions({ mentions, onMentionClick }: TopMentionsProps) {
  console.log('📋 TopMentions received:', mentions?.length || 0, 'mentions');
  
  const topMentions = useMemo(() => {
    if (!mentions || mentions.length === 0) {
      console.log('⚠️ TopMentions: No mentions');
      return [];
    }
    
    console.log('📋 TopMentions processing top 8');
    console.log('📋 First mention source:', mentions[0]?.source);
    
    return mentions.slice(0, 8).map((mention, index) => {
      // Usar directamente el type de source (LIVE_STREAM o RADIO_STREAM)
      const sourceType = mention.source?.type || 'WEB_SCRAPE';
      
      return {
        id: mention.id,
        rank: index + 1,
        title: mention.title || mention.keyword || mention.context?.substring(0, 50) || 'Sin titulo',
        type: sourceType,
        sourceName: mention.source?.name || 'Desconocido',
        color: colors[index % colors.length],
      };
    });
  }, [mentions]);
  
  console.log('📋 TopMentions final:', topMentions);

  return (
    <div className="glass-card" style={{ padding: '24px', height: '100%' }}>
      <div style={{ marginBottom: '16px' }}>
        <h3 style={{
          fontSize: '18px',
          fontWeight: 600,
          color: 'var(--text-primary)',
          display: 'flex',
          alignItems: 'center',
          gap: '8px'
        }}>
          <span style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            backgroundColor: '#eab308'
          }} />
          Notas con mayor alcance
        </h3>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {topMentions.map((mention) => {
          const Icon = typeIcons[mention.type as keyof typeof typeIcons] || Globe;
          
          return (
            <div
              key={mention.id}
              onClick={() => onMentionClick?.(mention.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                padding: '8px',
                borderRadius: '8px',
                transition: 'background-color 0.2s ease',
                cursor: onMentionClick ? 'pointer' : 'default',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = 'var(--bg-secondary)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = 'transparent';
              }}
            >
              <span style={{
                fontSize: '14px',
                fontFamily: 'monospace',
                color: 'var(--text-muted)',
                width: '20px'
              }}>
                {mention.rank}.
              </span>
              
              <div style={{
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                backgroundColor: mention.color,
                flexShrink: 0
              }} />
              
              <Icon size={16} style={{ color: 'var(--text-muted)', flexShrink: 0 }} />
              
              <span style={{
                fontSize: '14px',
                color: 'var(--text-primary)',
                flex: 1,
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap'
              }}>
                {mention.title}
              </span>
              
              {onMentionClick && (
                <ExternalLink 
                  size={16} 
                  style={{ 
                    color: 'var(--text-muted)',
                    flexShrink: 0,
                    opacity: 0,
                    transition: 'opacity 0.2s ease'
                  }}
                  className="hover-icon"
                />
              )}
            </div>
          );
        })}
      </div>

      <style>{`
        .glass-card > div > div:hover .hover-icon {
          opacity: 1 !important;
        }
      `}</style>
    </div>
  );
}